module scene03 {
	exports image;
	exports ex01;
	exports media;
	
	requires javafx.base;
	requires javafx.controls;
	requires javafx.fxml;
	requires javafx.graphics;
	requires javafx.media;
}